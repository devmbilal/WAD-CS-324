<?php
   
    // database details
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sampledb";

    /* creating a connection
    $con = mysqli_connect($host, $username, $password, $dbname);

    // to ensure that the connection is made
    if (!$con)
    {
        die("Connection failed!" . mysqli_connect_error());
    }
   
   $sql = 'SELECT id, fname, lname, email FROM contactform_entries';
     
   $retval = mysqli_query( $sql, $conn );
   
   if(! $retval ) {
      die('Could not get data: ' . mysqli_connect_error());
   }
   
   while($row = mysqli_fetch_array($retval, MYSQL_ASSOC)) {
      echo "Contact ID :{$row['id']}  <br> ".
         "Contact First Name : {$row['fname']} <br> ".
         "Contact Last Name : {$row['lname']} <br> ".
		 "Contact email : {$row['email']} <br> ".
         "--------------------------------<br>";
   }
   
   echo "Fetched data successfully\n";
   
   mysqli_close($conn);
   
 */  
   
   // Create connection
$conn = new mysqli($host, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, fname, lname, email FROM contactform_entries";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<br> id: ". $row["id"]. " - Name: ". $row["fname"]. " " . $row["lname"] . "- Email: ". $row["email"]. "<br>";
    }
} else {
    echo "0 results";
}

$conn->close();
?>