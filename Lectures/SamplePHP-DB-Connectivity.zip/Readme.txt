Install WAMP Server Software.
Start it. (Icon turns green)
Since PHP files execute at server end, the Files need to be placed on server (Wamp/www/ folder)
